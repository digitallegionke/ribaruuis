import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { a0a0affIcon } from './a0a0affIcon';
import { ImageIcon } from './ImageIcon';
import { InterfaceAlertAlarmBell2AlertB } from './InterfaceAlertAlarmBell2AlertB';
import { InterfaceHome1HomeHouseMapRoof } from './InterfaceHome1HomeHouseMapRoof';
import { InterfaceSettingCogWorkLoading } from './InterfaceSettingCogWorkLoading';
import { InterfaceSettingMenu1ButtonPar } from './InterfaceSettingMenu1ButtonPar';
import classes from './LandingPage.module.css';
import { Menu_Property1Home } from './Menu_Property1Home/Menu_Property1Home';
import { MoneyCashierShopShoppingPayPay } from './MoneyCashierShopShoppingPayPay';
import { ShippingBox2BoxPackageLabelDel } from './ShippingBox2BoxPackageLabelDel';

interface Props {
  className?: string;
}
/* @figmaId 54:447 */
export const LandingPage: FC<Props> = memo(function LandingPage(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.frame1618873481}>
        <div className={classes.frame1618873477}>
          <div className={classes._16788}>16,788</div>
          <div className={classes.tODAYSSALES}>TODAY’S SALES</div>
          <div className={classes.kES}>KES</div>
          <div className={classes.frame1618873524}>
            <div className={classes.tOTALSTOCKVALUE}>TOTAL STOCK VALUE</div>
            <div className={classes.frame1618873528}>
              <div className={classes.kES2}>KES</div>
              <div className={classes._45850}>45,850</div>
            </div>
          </div>
          <div className={classes.frame1618873526}>
            <div className={classes.lOWSTOCKITEMS}>LOW STOCK ITEMS</div>
            <div className={classes._5}>5</div>
          </div>
          <div className={classes.frame1618873525}>
            <div className={classes.tOTALITEMSINSTOCK}>TOTAL ITEMS IN STOCK</div>
            <div className={classes._150}>150</div>
          </div>
          <div className={classes.frame1618873527}>
            <div className={classes.yOURCUSTOMERs}>YOUR CUSTOMERs</div>
            <div className={classes._58}>58</div>
          </div>
        </div>
      </div>
      <div className={classes.frame1618873485}>
        <div className={classes.frame1618873484}>
          <div className={classes.heyKevin}>Hey Kevin</div>
          <div className={classes.welcomeBack}>Welcome Back</div>
        </div>
        <div className={classes.image}>
          <ImageIcon className={classes.icon5} />
        </div>
      </div>
      <div className={classes.frame16188735272}>
        <div className={classes.a0a0aff}>
          <a0a0affIcon className={classes.icon6} />
        </div>
        <div className={classes.frame1618873486}>
          <div className={classes.interfaceAlertAlarmBell2AlertB}>
            <InterfaceAlertAlarmBell2AlertB className={classes.icon7} />
          </div>
          <div className={classes.interfaceSettingMenu1ButtonPar}>
            <InterfaceSettingMenu1ButtonPar className={classes.icon8} />
          </div>
        </div>
      </div>
      <Menu_Property1Home
        className={classes.menu}
        classes={{ menu2: classes.menu2, menu3: classes.menu3, menu4: classes.menu4 }}
        swap={{
          interfaceHome1HomeHouseMapRoof: <InterfaceHome1HomeHouseMapRoof className={classes.icon} />,
          moneyCashierShopShoppingPayPay: <MoneyCashierShopShoppingPayPay className={classes.icon2} />,
          shippingBox2BoxPackageLabelDel: <ShippingBox2BoxPackageLabelDel className={classes.icon3} />,
          interfaceSettingCogWorkLoading: <InterfaceSettingCogWorkLoading className={classes.icon4} />,
        }}
      />
      <div className={classes.frame1618873512}>
        <div className={classes.frame1618873483}>
          <div className={classes.addASale}>Add a Sale</div>
        </div>
        <div className={classes.frame16188734842}>
          <div className={classes.addStock}>Add Stock</div>
        </div>
      </div>
    </div>
  );
});
