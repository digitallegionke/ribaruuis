import { memo, SVGProps } from 'react';

const InterfaceSettingMenu1ButtonPar = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 22 20' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_87_1924)'>
      <path
        d='M0.666686 16.6667L21.3334 16.6667'
        stroke='#0A1FDA'
        strokeWidth={1.33333}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M0.666686 10L21.3334 10'
        stroke='#0A1FDA'
        strokeWidth={1.33333}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M0.666686 3.33335L21.3334 3.33335'
        stroke='#0A1FDA'
        strokeWidth={1.33333}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </g>
    <defs>
      <clipPath id='clip0_87_1924'>
        <rect width={22} height={20} fill='white' transform='matrix(-1 0 0 1 22 1.04904e-05)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(InterfaceSettingMenu1ButtonPar);
export { Memo as InterfaceSettingMenu1ButtonPar };
