import { memo, SVGProps } from 'react';

const MoneyCashierShopShoppingPayPay = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 25 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g opacity={0.7} clipPath='url(#clip0_87_1949)'>
      <path
        d='M11.1192 18.1539H12.6577'
        stroke='#0A1FDA'
        strokeWidth={2.00321}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M16.5038 8.92307V5.84615'
        stroke='#0A1FDA'
        strokeWidth={2.00321}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M19.581 3.9231C19.581 4.17564 19.5313 4.42571 19.4347 4.65903C19.338 4.89235 19.1964 5.10434 19.0178 5.28292C18.8392 5.46149 18.6272 5.60315 18.3939 5.69979C18.1606 5.79643 17.9105 5.84617 17.658 5.84617H15.3503C14.8402 5.84617 14.3511 5.64357 13.9905 5.28292C13.6298 4.92227 13.4272 4.43313 13.4272 3.9231C13.4272 3.41307 13.6298 2.92392 13.9905 2.56328C14.3511 2.20263 14.8402 2.00002 15.3503 2.00002H17.658C17.9105 2.00002 18.1606 2.04976 18.3939 2.14641C18.6272 2.24305 18.8392 2.3847 19.0178 2.56328C19.1964 2.74185 19.338 2.95385 19.4347 3.18717C19.5313 3.42049 19.581 3.67056 19.581 3.9231V3.9231Z'
        stroke='#0A1FDA'
        strokeWidth={2.00321}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M9.58071 8.92312V3.5385H4.96532V8.92312'
        stroke='#0A1FDA'
        strokeWidth={2.00321}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M20.3503 14.3077H3.4272C2.57753 14.3077 1.88874 14.9965 1.88874 15.8462V20.4616C1.88874 21.3112 2.57753 22 3.4272 22H20.3503C21.1999 22 21.8887 21.3112 21.8887 20.4616V15.8462C21.8887 14.9965 21.1999 14.3077 20.3503 14.3077Z'
        stroke='#0A1FDA'
        strokeWidth={2.00321}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M20.3503 14.3077V10.4616C20.3503 10.0535 20.1882 9.66222 19.8997 9.3737C19.6112 9.08519 19.2198 8.9231 18.8118 8.9231H4.96566C4.55763 8.9231 4.16632 9.08519 3.8778 9.3737C3.58928 9.66222 3.4272 10.0535 3.4272 10.4616V14.3077'
        stroke='#0A1FDA'
        strokeWidth={2.00321}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </g>
    <defs>
      <clipPath id='clip0_87_1949'>
        <rect width={24} height={24} fill='white' transform='translate(0.333332 0.166666)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(MoneyCashierShopShoppingPayPay);
export { Memo as MoneyCashierShopShoppingPayPay };
